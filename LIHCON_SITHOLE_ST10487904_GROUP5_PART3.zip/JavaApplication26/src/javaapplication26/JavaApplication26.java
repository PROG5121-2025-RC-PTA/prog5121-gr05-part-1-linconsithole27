package javaapplication26;

import javax.swing.*;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;

public class JavaApplication26 {
    private HashMap<String, String> users = new HashMap<>();
    private HashMap<String, String> cellphones = new HashMap<>();
    private List<Message> sentMsgs = new ArrayList<>();
    private List<Message> disregardMsgs = new ArrayList<>();
    private List<Message> storedMsgs = new ArrayList<>();
    private List<String> msgHashes = new ArrayList<>();
    private List<String> msgIds = new ArrayList<>();
    private Scanner scanner = new Scanner(System.in);
    private boolean isLoggedIn = false;
    private String loggedInUser;

    public static void main(String[] args) {
        JavaApplication26 app = new JavaApplication26();
        app.startChat();
    }

    public void startChat() {
        System.out.println("Welcome to QuickChat App");
        while (true) {
            System.out.println("\nChoose an option:\n1. Register\n2. Login\n3. Logout");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1 -> regAcct();
                case 2 -> login();
                case 3 -> {
                    System.out.println("Thank you for using QuickChat");
                    return;
                }
                default -> System.out.println("Please enter the correct option");
            }
        }
    }

    private void regAcct() {
        System.out.println("\nRegister another account:");
        System.out.print("Enter your username (must contain '_' and be at most 5 characters long): ");
        String username = scanner.nextLine();
        while (!chkUsername(username)) {
            System.out.print("Invalid username. Must be <= 5 chars with '_': ");
            username = scanner.nextLine();
        }

        System.out.print("Enter your password (must be at least 8 characters, include a capital letter, a number, and a special character): ");
        String password = scanner.nextLine();
        while (!chkPassword(password)) {
            System.out.print("Invalid password: ");
            password = scanner.nextLine();
        }

        System.out.print("Enter your South African cellphone number (must start with '+27' followed by up to 10 digits): ");
        String cellphone = scanner.nextLine();
        while (!chkCellphone(cellphone)) {
            System.out.print("Invalid cellphone: ");
            cellphone = scanner.nextLine();
        }

        users.put(username, password);
        cellphones.put(username, cellphone);
        System.out.println("Registration successful!");
    }

    private void login() {
        System.out.println("\nLogin to your account:");
        System.out.print("Enter your username: ");
        String username = scanner.nextLine();

        if (!users.containsKey(username)) {
            System.out.println("Username not found. Please register first.");
            return;
        }

        System.out.print("Enter your password: ");
        String password = scanner.nextLine();

        if (users.get(username).equals(password)) {
            isLoggedIn = true;
            loggedInUser = username;
            System.out.println("Login successful! Welcome back, " + username + "!");
            showMenu();
        } else {
            System.out.println("Incorrect password. Try again.");
        }
    }

    private void showMenu() {
        while (true) {
            System.out.println("\nChoose an option:\n1. Send Messages\n2. Show Sent Messages\n3. Find Longest Message\n4. Search by Message ID\n5. Search by Recipient\n6. Delete by Hash\n7. Show Report\n8. Quit");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1 -> sendMsg();
                case 2 -> dispSent();
                case 3 -> findLongest();
                case 4 -> searchId();
                case 5 -> searchRecip();
                case 6 -> delByHash();
                case 7 -> showReport();
                case 8 -> {
                    System.out.println("Logging out. See you next time!");
                    isLoggedIn = false;
                    return;
                }
                default -> System.out.println("Invalid option. Try again.");
            }
        }
    }

    private void sendMsg() {
        System.out.print("How many messages do you want to enter? ");
        int numMessages = scanner.nextInt();
        scanner.nextLine();

        for (int i = 0; i < numMessages; i++) {
            System.out.print("\nEnter recipient's cellphone number (+27 followed by up to 10 digits): ");
            String recipient = scanner.nextLine();
            while (!chkCellphone(recipient)) {
                System.out.print("Incorrect number. Please Enter again: ");
                recipient = scanner.nextLine();
            }

            System.out.print("Enter your message (maximum 250 characters): ");
            String messageText = scanner.nextLine();
            while (messageText.length() > 250) {
                System.out.println("Message too long. Please enter a message under 250 characters.");
                messageText = scanner.nextLine();
            }

            Message message = new Message(recipient, messageText);
            msgIds.add(message.getId());
            msgHashes.add(message.genHash());
            System.out.println("\nChoose an option:\n1. Send Message\n2. Disregard Message\n3. Store Message");
            int action = scanner.nextInt();
            scanner.nextLine();

            switch (action) {
                case 1 -> {
                    sentMsgs.add(message);
                    JOptionPane.showMessageDialog(null, message.dispMsg());
                    System.out.println("Message sent!");
                }
                case 2 -> {
                    disregardMsgs.add(message);
                    System.out.println("Message disregarded.");
                }
                case 3 -> {
                    storedMsgs.add(message);
                    storeMsg(message);
                    System.out.println("Message stored.");
                }
                default -> System.out.println("Invalid option.");
            }
        }
        System.out.println("\nTotal messages sent: " + sentMsgs.size());
    }

    private void storeMsg(Message message) {
        try (FileWriter writer = new FileWriter("storedMessages.json", true)) {
            writer.write(message.toJson() + "\n");
        } catch (IOException e) {
            System.out.println("Error storing message.");
        }
    }

    private void dispSent() {
        if (sentMsgs.isEmpty()) {
            System.out.println("No sent messages.");
            return;
        }
        for (Message msg : sentMsgs) {
            System.out.println("Sender: " + loggedInUser + ", Recipient: " + msg.getRecip() + ", Message: " + msg.getMsg());
        }
    }

    private void findLongest() {
        if (sentMsgs.isEmpty()) {
            System.out.println("No sent messages.");
            return;
        }
        Message longest = sentMsgs.get(0);
        for (Message msg : sentMsgs) {
            if (msg.getMsg().length() > longest.getMsg().length()) {
                longest = msg;
            }
        }
        System.out.println("Longest message: " + longest.getMsg());
    }

    private void searchId() {
        System.out.print("Enter message ID: ");
        String id = scanner.nextLine();
        for (Message msg : sentMsgs) {
            if (msg.getId().equals(id)) {
                System.out.println("Recipient: " + msg.getRecip() + ", Message: " + msg.getMsg());
                return;
            }
        }
        System.out.println("Message ID not found.");
    }

    private void searchRecip() {
        System.out.print("Enter recipient's number: ");
        String recip = scanner.nextLine();
        boolean found = false;
        for (Message msg : sentMsgs) {
            if (msg.getRecip().equals(recip)) {
                System.out.println("Message: " + msg.getMsg());
                found = true;
            }
        }
        for (Message msg : storedMsgs) {
            if (msg.getRecip().equals(recip)) {
                System.out.println("Stored Message: " + msg.getMsg());
                found = true;
            }
        }
        if (!found) {
            System.out.println("No messages found for this recipient.");
        }
    }

    private void delByHash() {
        System.out.print("Enter message hash: ");
        String hash = scanner.nextLine();
        for (int i = 0; i < msgHashes.size(); i++) {
            if (msgHashes.get(i).equals(hash)) {
                Message msg = findMsgByHash(hash);
                if (msg != null) {
                    sentMsgs.remove(msg);
                    storedMsgs.remove(msg);
                    disregardMsgs.remove(msg);
                    msgHashes.remove(i);
                    msgIds.remove(msg.getId());
                    System.out.println("Message deleted: " + msg.getMsg());
                    return;
                }
            }
        }
        System.out.println("Hash not found.");
    }

    private Message findMsgByHash(String hash) {
        for (Message msg : sentMsgs) {
            if (msg.genHash().equals(hash)) return msg;
        }
        for (Message msg : storedMsgs) {
            if (msg.genHash().equals(hash)) return msg;
        }
        for (Message msg : disregardMsgs) {
            if (msg.genHash().equals(hash)) return msg;
        }
        return null;
    }

    private void showReport() {
        if (sentMsgs.isEmpty()) {
            System.out.println("No sent messages.");
            return;
        }
        System.out.println("\nSent Messages Report:");
        for (Message msg : sentMsgs) {
            System.out.println("Hash: " + msg.genHash() + ", Recipient: " + msg.getRecip() + ", Message: " + msg.getMsg());
        }
    }

    private boolean chkUsername(String username) {
        return username.contains("_") && username.length() <= 5;
    }

    private boolean chkPassword(String password) {
        return password.matches(".*[A-Z].*") && password.matches(".*\\d.*") &&
               password.matches(".*[!@#$%^&()+?{}].*") && password.length() >= 8;
    }

    private boolean chkCellphone(String cellphone) {
        return cellphone.matches("^\\+27\\d{1,11}$");
    }

    // Getters for testing
    public List<Message> getSentMsgs() { return sentMsgs; }
    public List<Message> getStoredMsgs() { return storedMsgs; }
    public List<String> getMsgHashes() { return msgHashes; }
    public List<String> getMsgIds() { return msgIds; }
}

class Message {
    private final String id;
    private final String recip;
    private final String msg;
    private static int msgCount = 0;

    public Message(String recip, String msg) {
        this.id = String.valueOf((int) (Math.random() * 1000000000));
        this.recip = recip;
        this.msg = msg;
        msgCount++;
    }

    public String genHash() {
        String[] words = msg.split(" ");
        String first = words.length > 0 ? words[0] : "";
        String last = words.length > 1 ? words[words.length - 1] : "";
        return id.substring(0, 2) + ":" + msgCount + ":" + first.toUpperCase() + last.toUpperCase();
    }

    public String dispMsg() {
        return "Message ID: " + id + "\nMessage Hash: " + genHash() + "\nRecipient: " + recip + "\nMessage: " + msg;
    }

    public String toJson() {
        return "{ \"MessageID\": \"" + id + "\", \"Recipient\": \"" + recip + "\", \"Message\": \"" + msg + "\" }";
    }

    public String getId() { return id; }
    public String getRecip() { return recip; }
    public String getMsg() { return msg; }
}
//this project was made by reffering to copilot
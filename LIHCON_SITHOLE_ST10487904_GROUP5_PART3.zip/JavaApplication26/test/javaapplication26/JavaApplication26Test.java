/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package javaapplication26;

import java.util.List;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author RC_Student_lab
 */
public class JavaApplication26Test {
    
    public JavaApplication26Test() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of main method, of class JavaApplication26.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        JavaApplication26.main(args);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of startChat method, of class JavaApplication26.
     */
    @Test
    public void testStartChat() {
        System.out.println("startChat");
        JavaApplication26 instance = new JavaApplication26();
        instance.startChat();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getSentMsgs method, of class JavaApplication26.
     */
    @Test
    public void testGetSentMsgs() {
        System.out.println("getSentMsgs");
        JavaApplication26 instance = new JavaApplication26();
        List<Message> expResult = null;
        List<Message> result = instance.getSentMsgs();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getStoredMsgs method, of class JavaApplication26.
     */
    @Test
    public void testGetStoredMsgs() {
        System.out.println("getStoredMsgs");
        JavaApplication26 instance = new JavaApplication26();
        List<Message> expResult = null;
        List<Message> result = instance.getStoredMsgs();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getMsgHashes method, of class JavaApplication26.
     */
    @Test
    public void testGetMsgHashes() {
        System.out.println("getMsgHashes");
        JavaApplication26 instance = new JavaApplication26();
        List<String> expResult = null;
        List<String> result = instance.getMsgHashes();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getMsgIds method, of class JavaApplication26.
     */
    @Test
    public void testGetMsgIds() {
        System.out.println("getMsgIds");
        JavaApplication26 instance = new JavaApplication26();
        List<String> expResult = null;
        List<String> result = instance.getMsgIds();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}

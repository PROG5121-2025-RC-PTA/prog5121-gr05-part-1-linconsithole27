/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package leepoe;
//LIHCON SITHOLE POE PART ONE ST10487904
import javax.swing.*;
import java.util.HashMap;

public class LeePOE {

    private HashMap<String, String> users = new HashMap<>();

    public static void main(String[] args) {
        LeePOE app = new LeePOE();
        app.lincon();
    }
//Method before login
    //refferd to Copilot
    public void lincon() {
        String[] options = {"Register", "Login"};
        int choice = JOptionPane.showOptionDialog(
            null,
            "Welcome! Please choose an option:",
            "MyPOE",
            JOptionPane.DEFAULT_OPTION,
            JOptionPane.INFORMATION_MESSAGE,
            null,
            options,
            options[0]
        );

        switch (choice) {
            case 0 -> register();
            case 1 -> login();
            default -> JOptionPane.showMessageDialog(null, "Enter a correct option");
        }
    }
//Method to register where user input their information
    //Some information reffered to Copilot
    private void register() {
        String username = JOptionPane.showInputDialog(
            null,
            "Enter your username (must contain '_' and it must be atleast 5 characters long):",
            "Register",
            JOptionPane.INFORMATION_MESSAGE
        );

        while (!checkUsername(username)) {
            username = JOptionPane.showInputDialog(
                null,
                "Username is not correctly formatted,please ensure that your username contains"
                        + "an underscore and is no more than five characters in length",
                "Register",
                JOptionPane.ERROR_MESSAGE
            );
        }

        String password = JOptionPane.showInputDialog(
            null,
            "Enter your password (must be at least 8 characters, include a capital letter, a number, and a special character):",
            "Register",
            JOptionPane.INFORMATION_MESSAGE
        );

        while (!checkPassword(password)) {
            password = JOptionPane.showInputDialog(
                null,
                """
                Password is not correctly formatted.
                Please ensure it includes:
                - At least 8 characters
                - A capital letter
                - A number
                - A special character""",
                "Register",
                JOptionPane.ERROR_MESSAGE
            );
        }

        String cellphoneNumber = JOptionPane.showInputDialog(
            null,
            "Enter your cellphone number (must include country code and be no more than 10 characters long):",
            "Register",
            JOptionPane.INFORMATION_MESSAGE
        );

        while (!checkCellphoneNumber(cellphoneNumber)) {
            cellphoneNumber = JOptionPane.showInputDialog(
                null,
                "Cellphone number incorrectly formatted or does not contain international code",
                "Register",
                JOptionPane.ERROR_MESSAGE
            );
        }

        users.put(username, password);
        JOptionPane.showMessageDialog(null, "Welcome"+username+"it is great to see you again");
        login(username);
    }
//Method for the user to login after registration
    //reffered to Copilot
    private void login() {
        String username = JOptionPane.showInputDialog(
            null,
            "Please Enter your username:",
            "Login",
            JOptionPane.INFORMATION_MESSAGE
        );

        if (!users.containsKey(username)) {
            JOptionPane.showMessageDialog(null, "Please enter a correct username");
            return;
        }

        String password = JOptionPane.showInputDialog(
            null,
            "Please Enter your password:",
            "Login",
            JOptionPane.INFORMATION_MESSAGE
        );

        if (users.get(username).equals(password)) {
            JOptionPane.showMessageDialog(null, "You were able to login Welcome back, " + username);
        } else {
            JOptionPane.showMessageDialog(null, "Please Enter a correct password");
        }
    }

    // Login method
   //reffered to Copilot
    private void login(String username) {
        JOptionPane.showMessageDialog(null, "Login successful! Welcome, " + username + "!");
    }

    private boolean checkUsername(String username) {
        if (username != null && username.contains("_") && username.length() <= 5) {
            JOptionPane.showMessageDialog(null, "Username successfully captured.");
            return true;
        } else {
            JOptionPane.showMessageDialog(null, "Username is not correctly formatted please"
                    + "ensure that the username contains an underscore");
            return false;
        }
    }
//Method to check password
    //reffered to Copilot
    private boolean checkPassword(String password) {
        if (password != null && password.length() >= 8 &&
            password.matches(".*[A-Z].*") &&
            password.matches(".*\\d.*") &&
            password.matches(".*[!@#$%^&*()+?{}].*")) {
            JOptionPane.showMessageDialog(null, "Password successfully captured.");
            return true;
        } else {
            JOptionPane.showMessageDialog(null, """
                    Password is not correctly formatted.
                    Please ensure that the password contains at least:
                    - Eight characters
                    - A capital letter
                    - A number
                    - A special character
                    """);
            return false;
        }
    }
//Method to check cellphone number
    //Refered to Copilot
    private boolean checkCellphoneNumber(String cellphoneNumber) {
        if (cellphoneNumber != null && cellphoneNumber.startsWith("+")) {
            String remainingNumber = cellphoneNumber.substring(1);
            if (remainingNumber.length() <= 10 && remainingNumber.matches("\\d+")) {
                JOptionPane.showMessageDialog(null, "Cellphone number successfully captured.");
                return true;
            } else {
                JOptionPane.showMessageDialog(null, "Cellphone number must contain only numeric digits and be no more than 10 characters long.");
                return false;
            }
        } else {
            JOptionPane.showMessageDialog(null, "Cellphone number is incorectly formatted or does not contain"
                    + "a international code");
            return false;
        }
    }
}

    
    


package javaapplication23;

import javax.swing.*;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;

public class JavaApplication23 {

    private HashMap<String, String> users = new HashMap<>(); // Stores username AND paaswords
    private HashMap<String, String> cellphones = new HashMap<>(); // Stores username AND hone mapping
    private List<Message> messages = new ArrayList<>(); // Stores sent messages
    private Scanner scanner = new Scanner(System.in);
    private boolean isLoggedIn = false;
    private String loggedInUser;

    public static void main(String[] args) {
        JavaApplication23 app = new JavaApplication23();
        app.quickchat();
    }
//Method to enter the Qickchat app
    public void quickchat(){
        System.out.println("Welcome to QuickChat App");
        while (true) {
            System.out.println("\nChoose an option:\n1. Register\n2. Login\n3. Logout");
            int choice = scanner.nextInt();
            scanner.nextLine(); 

            switch (choice) {
                case 1 -> registerAccount();
                case 2 -> login();
                case 3 -> {
                    System.out.println("Thank you for using QuickChat");
                    return;
                }
                default -> System.out.println(" Please enter the correct option");
            }
        }
    }
//Method to register your account
    private void registerAccount() {
        System.out.println("\nRegister another account:");

        System.out.print("Enter your username (must contain '_' and be at most 5 characters long): ");
        String username = scanner.nextLine();
//While loop to check username
        while (!checkUsername(username)) {
            System.out.print("The user name was incorrectly formmated.The username must be atleast 5 characters long and an underscore ");
            username = scanner.nextLine();
        }

        System.out.print("Enter your password (must be at least 8 characters, include a capital letter, a number, and a special character): ");
        String password = scanner.nextLine();
//While loop to check password
        while (!checkPassword(password)) {
            System.out.print("Please enter the correct password ");
            password = scanner.nextLine();
        }

        System.out.print("Enter your South African cellphone number (must start with '+27' followed by up to 10 digits): ");
        String cellphone = scanner.nextLine();
//Method to check cellphone number
        while (!checkCellphone(cellphone)) {
            System.out.print("Please enter the correct form of numbers ");
            cellphone = scanner.nextLine();
        }

        users.put(username, password);
        cellphones.put(username, cellphone);
        System.out.println("Registration successful!");
    }
//Method for login
    private void login() {
        System.out.println("\nLogin to your account:");
        System.out.print("Enter your username: ");
        String username = scanner.nextLine();

        if (!users.containsKey(username)) {
            System.out.println("Username not found. Please register first.");
            return;
        }

        System.out.print("Enter your password: ");
        String password = scanner.nextLine();

        if (users.get(username).equals(password)) {
            isLoggedIn = true;
            loggedInUser = username;
            System.out.println("Login successful! Welcome back, " + username + "!");

            chooseMenu();
        } else {
            System.out.println("Incorrect password. Try again.");
        }
    }

    private void chooseMenu() {
        while (true) {
            System.out.println("\nChoose an option:\n1. Send Messages\n2. Show Recently Sent Messages\n3. Quit");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1 -> sendMessage();
                case 2 -> System.out.println("Coming Soon.");
                case 3 -> {
                    System.out.println("Logging out. See you next time!");
                    isLoggedIn = false;
                    return;
                }
                default -> System.out.println("Invalid option. Try again.");
            }
        }
    }

    private void sendMessage() {
        System.out.print("How many messages do you want to enter? ");
        int numMessages = scanner.nextInt();
        scanner.nextLine(); 

        for (int i = 0; i < numMessages; i++) {
            System.out.print("\nEnter recipient's cellphone number (+27 followed by up to 10 digits): ");
            String recipient = scanner.nextLine();
            while (!checkCellphone(recipient)) {
                System.out.print("Incorrect number.Please Enter again: ");
                recipient = scanner.nextLine();
            }

            System.out.print("Enter your message (maximum to 250 characters): ");
            String messageText = scanner.nextLine();
            while (messageText.length() > 250) {
                System.out.println("Message too long. Please enter a message under 250 characters.");
                messageText = scanner.nextLine();
            }

            Message message = new Message(recipient, messageText);
            messages.add(message);
            JOptionPane.showMessageDialog(null, message.dispMessage());

            System.out.println("\nChoose an option:\n1. Send Message\n2. Disregard Message\n3. Store Message to Send Later");
            int action = scanner.nextInt();
            scanner.nextLine();

            if (action == 3) storeMessage(message);
        }

        System.out.println("\nTotal messages sent: " + messages.size());
    }

    private void storeMessage(Message message) {
        try (FileWriter writer = new FileWriter("storedMessages.json", true)) {
            writer.write(message.toJson() + "\n");
            System.out.println("Message stored successfully.");
        } catch (IOException e) {
            System.out.println("Error storing message.");
        }
    }

    private boolean checkUsername(String username) {
        return username.contains("_") && username.length() <= 5;
    }
//BOOLEAN STATEMENT TO CHECK PASSWORD
    private boolean checkPassword(String password) {
        return password.matches(".*[A-Z].*") && password.matches(".*\\d.*") &&
               password.matches(".*[!@#$%^&*()+?{}].*") && password.length() >= 8;
    }
//boolean statement to check if the password is true 
    private boolean checkCellphone(String cellphone) {
        return cellphone.matches("^\\+27\\d{1,11}$");
    }
}
class Message {
    //attibutes
    private final String id;
    private final String recipient;
    private final String message;
    private static int messageCounter = 0;
//Method for the recipient message
    public Message(String recipient, String message) {
        this.id = String.valueOf((int) (Math.random() * 1000000000));
        this.recipient = recipient;
        this.message = message;
        messageCounter++;
    }
    //Method to check
    //REFERRED TO COPILOT

    public String createMessageHash() {
        String[] words = message.split(" ");
        String first = words.length > 0 ? words[0] : "";
        String last = words.length > 1 ? words[words.length - 1] : "";
        return id.substring(0, 2) + ":" + messageCounter + ":" + first.toUpperCase() + last.toUpperCase();
    }
//Method to display meassage
    public String dispMessage() {
        return "Message: " + id + "\nMessage Hash: " + createMessageHash() + "\nRecipient: " + recipient + "\nMessage: " + message;
    }

    public String toJson() {
        return "{ \"MessageID\": \"" + id + "\", \"Recipient\": \"" + recipient + "\", \"Message\": \"" + message + "\" }";
    }
}

